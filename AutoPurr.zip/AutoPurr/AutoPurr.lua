-- Configuration and State
local isAutoPurrEnabled = true
local locale = GetLocale()
local trigger = "pets you"
local response = "purrs at %s."

if locale == "deDE" then
    trigger = "streichelt Euch"
    response = "schnurrt %s an."
end

-- Slash Command Logic (/autopurr)
SLASH_AUTOPURR1 = "/autopurr"
SlashCmdList["AUTOPURR"] = function(msg)
    isAutoPurrEnabled = not isAutoPurrEnabled
    local status = isAutoPurrEnabled and "|cff00ff00Enabled|r" or "|cffff0000Disabled|r"
    print("|cff00ccffAutoPurr Toggle:|r " .. status)
end

-- Event Frame
local f = CreateFrame("Frame")
f:RegisterEvent("CHAT_MSG_TEXT_EMOTE")
f:SetScript("OnEvent", function(self, event, msg, sender)
    -- 1. Check if the addon is manually toggled on
    -- 2. Check if the player is currently in combat (to prevent lag/clutter)
    if not isAutoPurrEnabled or UnitAffectingCombat("player") then 
        return 
    end

    -- Check for the language-specific trigger
    if msg:find(trigger) then
        
        -- Check for Feral/Ghost Wolf forms
        local isFeral = UnitBuff("player", "Ghost Wolf") or UnitBuff("player", "Geisterwolf") or 
                        UnitBuff("player", "Cat Form") or UnitBuff("player", "Katzengestalt")

        if isFeral then
            local output = string.format(response, sender)
            SendChatMessage(output, "EMOTE") 
        end
    end
end)